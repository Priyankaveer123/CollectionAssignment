package master_assignment.manager;

public class TestResultManager {

}
