package com.one;

public class BookSale {
	public Book b;
	int copiesSold;
	public BookSale(Book b, int copiesSold) {
		this.b = b;
		this.copiesSold = copiesSold;
	}
	
}
