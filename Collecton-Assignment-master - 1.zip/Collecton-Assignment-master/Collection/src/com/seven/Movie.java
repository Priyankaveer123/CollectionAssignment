package hashmap;

import java.util.ArrayList;
import java.util.List;

//import java.awt.List;

public class Movie 
{
	int mid;
	String Mnm;
	//List l[]=new List[10];
	List<Actor>L=new ArrayList<>();
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getMnm() {
		return Mnm;
	}
	public void setMnm(String mnm) {
		Mnm = mnm;
	}
	public List<Actor> getL() {
		return L;
	}
	public void setL(List<Actor> l) {
		L = l;
	}
	@Override
	public String toString() {
		return "Movie [mid=" + mid + ", Mnm=" + Mnm + ", L=" + L + "]";
	}
	
	
	
	
}
