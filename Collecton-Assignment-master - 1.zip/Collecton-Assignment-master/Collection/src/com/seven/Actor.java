package hashmap;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Actor
{
	int aid;
	String anm;
	int age;
	char g;
	public Actor(int aid, String anm, int age, char g) {
		super();
		this.aid = aid;
		this.anm = anm;
		this.age = age;
		this.g = g;
	}
	@Override
	public String toString() {
		return "Actor [aid=" + aid + ", anm=" + anm + ", age=" + age + ", g=" + g + "]";
	}
	
	
}