package hashmap;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Test {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Movie m=new Movie();
		m.setMid(10);
		m.setMnm("Black");
		Movie m1=new Movie();
		m1.setMid(2);
		m1.setMnm("Padmavati");
		List<Actor>l=m.getL();
		l.add(new Actor(1,"Amit",70,'M'));
		l.add(new Actor(2,"Rani",30,'F'));
		l.add(new Actor(3,"Jaya",60,'F'));
		l.add(new Actor(4,"Akshay",50,'M'));
		m.setL(l);
		List<Actor>l2=m1.getL();
		l2.add(new Actor(5,"deepika",25,'F'));
		l2.add(new Actor(6,"Shahid",33,'M'));
		l2.add(new Actor(7,"RanVeer",30,'M'));
		l2.add(new Actor(9,"Akshay",27,'F'));
		m1.setL(l2);
		HashMap<String,Movie>hm=new HashMap<>();
	     // hm.put("Black",m);
	      hm.put("Padmavati", m1);
		System.out.println(hm);
		
	}

}